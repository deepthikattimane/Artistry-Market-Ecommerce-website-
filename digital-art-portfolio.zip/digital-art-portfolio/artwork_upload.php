<?php
require_once "db/connect.php";
session_start();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $price = floatval($_POST['price']);
    $artist_id = $_SESSION['user_id'];

    // Handle image upload
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $img_name = basename($_FILES['image']['name']);
        $target_path = "images/" . $img_name;

        if (move_uploaded_file($_FILES['image']['tmp_name'], $target_path)) {
            // Save to DB
            $stmt = $conn->prepare("INSERT INTO artworks (title, price, image_url, artist_id) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("sdsi", $title, $price, $img_name, $artist_id);
            $stmt->execute();

            echo "<p style='color:green;'>Artwork uploaded successfully!</p>";
        } else {
            echo "<p style='color:red;'>Failed to move uploaded image.</p>";
        }
    } else {
        echo "<p style='color:red;'>Please upload a valid image.</p>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Upload Artwork</title>
</head>
<body>
  <h2>Upload Your Artwork</h2>
  <form method="POST" enctype="multipart/form-data">
    <label>Title:</label><br>
    <input type="text" name="title" required><br><br>

    <label>Price (₹):</label><br>
    <input type="number" name="price" step="0.01" required><br><br>

    <label>Image:</label><br>
    <input type="file" name="image" accept="image/*" required><br><br>

    <button type="submit">Upload</button>
  </form>
</body>
</html>
