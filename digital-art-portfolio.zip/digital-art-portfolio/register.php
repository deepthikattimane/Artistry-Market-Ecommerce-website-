<?php
require_once "db/connect.php";
$msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = mysqli_real_escape_string($conn, $_POST["username"]);
    $email = mysqli_real_escape_string($conn, $_POST["email"]);
    $phone = mysqli_real_escape_string($conn, $_POST["phone"]);
    $password = password_hash($_POST["password"], PASSWORD_BCRYPT);
    $user_type = $_POST["user_type"];

    $check = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");
    if (mysqli_num_rows($check) > 0) {
        $msg = "Email already registered.";
    } else {
        $query = "INSERT INTO users (username, email, phone, password, user_type)
                  VALUES ('$username', '$email', '$phone', '$password', '$user_type')";
        if (mysqli_query($conn, $query)) {
            header("Location: login.php?success=registered");
            exit();
        } else {
            $msg = "Error: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Register | Artistry Market</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    :root {
      --primary-color: #2D4C46;
      --accent-color: #F6C544;
      --background-color: #F3E3AC;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Poppins', sans-serif;
    }

    body {
      background-color: var(--background-color);
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    .form-container {
      background-color: #fff;
      padding: 40px 30px;
      border-radius: 16px;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
      width: 100%;
      max-width: 450px;
      text-align: center;
    }

    .form-container h2 {
      margin-bottom: 20px;
      color: var(--primary-color);
      font-size: 28px;
    }

    .form-container input,
    .form-container select {
      width: 100%;
      padding: 12px 15px;
      margin: 10px 0;
      border: 1px solid #ccc;
      border-radius: 10px;
      outline: none;
      transition: 0.3s;
    }

    .form-container input:focus,
    .form-container select:focus {
      border-color: var(--primary-color);
      box-shadow: 0 0 5px rgba(45, 76, 70, 0.3);
    }

    .form-container button {
      width: 100%;
      padding: 12px;
      background-color: var(--primary-color);
      border: none;
      border-radius: 10px;
      color: white;
      font-weight: bold;
      font-size: 16px;
      margin-top: 10px;
      cursor: pointer;
      transition: background 0.3s;
    }

    .form-container button:hover {
      background-color: #3d6a5f;
    }

    .form-container .msg {
      color: red;
      margin-top: 10px;
      font-size: 14px;
    }

    .form-container p {
      margin-top: 15px;
      font-size: 14px;
    }

    .form-container a {
      color: var(--primary-color);
      text-decoration: none;
      font-weight: bold;
    }

    .form-container a:hover {
      color: var(--accent-color);
      text-decoration: underline;
    }

    @media (max-width: 480px) {
      .form-container {
        padding: 30px 20px;
      }
    }
  </style>
</head>
<body>
  <div class="form-container">
    <h2>Create Account</h2>
    <form method="post">
      <input type="text" name="username" placeholder="Full Name" required>
      <input type="email" name="email" placeholder="Email" required>
      <input type="tel" name="phone" placeholder="Phone Number">
      <input type="password" name="password" placeholder="Password" required>

      <select name="user_type" required>
        <option value="">I am a...</option>
        <option value="artist">Artist</option>
        <option value="visitor">Visitor</option>
      </select>

      <button type="submit">Register</button>
      <p class="msg"><?= $msg ?></p>
      <p>Already have an account? <a href="login.php">Login</a></p>
    </form>
  </div>
</body>
</html>
