<?php
session_start();
require_once "db/connect.php";

if (!isset($_SESSION['user_id'])) {
    echo json_encode(["status" => "not_logged_in"]);
    exit();
}

$user_id = $_SESSION['user_id'];
$art_id = isset($_POST['art_id']) ? intval($_POST['art_id']) : 0;

if ($art_id <= 0) {
    echo json_encode(["status" => "invalid_art_id"]);
    exit();
}

$check = $conn->prepare("SELECT * FROM favorites WHERE user_id = ? AND artwork_id = ?");
$check->bind_param("ii", $user_id, $art_id);
$check->execute();
$result = $check->get_result();

if ($result->num_rows > 0) {
    $delete = $conn->prepare("DELETE FROM favorites WHERE user_id = ? AND artwork_id = ?");
    $delete->bind_param("ii", $user_id, $art_id);
    $delete->execute();
    echo json_encode(["status" => "removed"]);
} else {
    $insert = $conn->prepare("INSERT INTO favorites (user_id, artwork_id) VALUES (?, ?)");
    $insert->bind_param("ii", $user_id, $art_id);
    if ($insert->execute()) {
        echo json_encode(["status" => "added"]);
    } else {
        echo json_encode(["status" => "error"]);
    }
}
?>
