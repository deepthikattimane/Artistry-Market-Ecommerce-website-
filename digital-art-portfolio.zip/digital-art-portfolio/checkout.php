<?php
session_start();
require_once "db/connect.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$art_id = isset($_GET['art_id']) ? intval($_GET['art_id']) : 0;
$sql = "SELECT a.*, u.username FROM artworks a JOIN users u ON a.artist_id = u.id WHERE a.id = $art_id";
$result = mysqli_query($conn, $sql);
$art = mysqli_fetch_assoc($result);

if (!$art) {
    echo "Artwork not found.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Checkout | Artistry Market</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f5f5f5;
      padding: 50px;
    }

    .checkout-form {
      max-width: 600px;
      margin: auto;
      background: #fff;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }

    h2 {
      text-align: center;
      margin-bottom: 20px;
    }

    img {
      max-width: 100%;
      height: auto;
      border-radius: 10px;
      margin-bottom: 20px;
    }

    .form-group {
      margin-bottom: 15px;
    }

    .form-group label {
      display: block;
      margin-bottom: 6px;
      font-weight: bold;
    }

    .form-group input,
    .form-group textarea,
    .form-group select {
      width: 100%;
      padding: 10px;
      border-radius: 6px;
      border: 1px solid #ccc;
    }

    .submit-btn {
      background: #2D4C46;
      color: white;
      padding: 12px;
      border: none;
      border-radius: 6px;
      font-size: 16px;
      width: 100%;
      cursor: pointer;
    }

    .submit-btn:hover {
      background: #3c6d61;
    }

    .hidden {
      display: none;
    }

    .price-display {
      font-weight: bold;
      color: #333;
      margin-top: 10px;
    }
  </style>

  <script>
    function togglePaymentFields() {
      const method = document.getElementById("payment_method").value;
      document.getElementById("upi-fields").style.display = (method === "UPI Payment") ? "block" : "none";
      document.getElementById("card-fields").style.display = (method === "Card Payment") ? "block" : "none";
    }

    function updateTotalPrice() {
      const pricePerItem = <?= $art['price'] ?>;
      const quantity = document.getElementById("quantity").value;
      const total = pricePerItem * quantity;
      document.getElementById("total_price").value = total;
      document.getElementById("display_price").innerText = "Total Price: ₹" + total;
    }
  </script>
</head>
<body>

  <form action="orders/place_order.php" method="POST" class="checkout-form">
    <h2>Checkout</h2>

    <input type="hidden" name="art_id" value="<?= $art['id'] ?>">
    <input type="hidden" name="price" value="<?= $art['price'] ?>">
    <input type="hidden" name="total_price" id="total_price" value="<?= $art['price'] ?>">


    <div class="form-group">
      <label>Artwork Title</label>
      <input type="text" value="<?= htmlspecialchars($art['title']) ?>" disabled>
    </div>

    <div class="form-group">
      <label>Price Per Item</label>
      <input type="text" value="₹<?= $art['price'] ?>" disabled>
    </div>

    <div class="form-group">
      <label>Quantity</label>
      <input type="number" id="quantity" name="quantity" value="1" min="1" required onchange="updateTotalPrice()" onkeyup="updateTotalPrice()">
    </div>

    <div class="form-group price-display" id="display_price">Total Price: ₹<?= $art['price'] ?></div>

    <div class="form-group">
      <label>Full Address</label>
      <textarea name="address" rows="3" required></textarea>
    </div>

    <div class="form-group">
      <label>Phone Number</label>
      <input type="tel" name="phone" pattern="[0-9]{10}" required>
    </div>

    <div class="form-group">
      <label>Pin Code</label>
      <input type="text" name="pincode" pattern="[0-9]{6}" required>
    </div>

    <div class="form-group">
      <label>Payment Method</label>
      <select name="payment_method" id="payment_method" onchange="togglePaymentFields()" required>
        <option value="" disabled selected>Select a payment method</option>
        <option value="Cash on Delivery">Cash on Delivery</option>
        <option value="UPI Payment">UPI Payment</option>
        <option value="Card Payment">Card Payment</option>
      </select>
    </div>

    <!-- UPI Details -->
    <div id="upi-fields" class="form-group hidden">
      <label>UPI ID</label>
      <input type="text" name="upi_id" placeholder="example@upi">
    </div>

    <!-- Card Details -->
    <div id="card-fields" class="hidden">
      <div class="form-group">
        <label>Cardholder Name</label>
        <input type="text" name="card_name" placeholder="John Doe">
      </div>
      <div class="form-group">
        <label>Card Number</label>
        <input type="text" name="card_number" maxlength="16" placeholder="1234 5678 9012 3456">
      </div>
      <div class="form-group">
        <label>Expiry Date</label>
        <input type="month" name="card_expiry">
      </div>
      <div class="form-group">
        <label>CVV</label>
        <input type="password" name="card_cvv" maxlength="3" placeholder="123">
      </div>
    </div>

    <button type="submit" class="submit-btn">Place Order</button>
  </form>

</body>
</html>
