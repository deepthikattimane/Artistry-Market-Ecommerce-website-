<?php
session_start();
require_once "db/connect.php";

// Handle search input
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';
$sql = "SELECT a.*, u.username AS artist_name 
        FROM artworks a 
        JOIN users u ON a.artist_id = u.id";

if (!empty($search)) {
    $sql .= " WHERE a.title LIKE '%$search%' OR u.username LIKE '%$search%'";
}

$sql .= " ORDER BY a.created_at DESC LIMIT 6";
$result = mysqli_query($conn, $sql);

// Get favorited artwork IDs for logged-in user
$favorited_ids = [];
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $fav_sql = "SELECT artwork_id FROM favorites WHERE user_id = ?";
    $fav_stmt = $conn->prepare($fav_sql);
    $fav_stmt->bind_param("i", $user_id);
    $fav_stmt->execute();
    $fav_result = $fav_stmt->get_result();
    while ($row = $fav_result->fetch_assoc()) {
        $favorited_ids[] = $row['artwork_id'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Features | Artistry Market</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    :root {
      --primary-color: #2D4C46;
      --accent-color: #F6C544;
      --background-color: #F3E3AC;
      --card-bg: #fff;
    }

    body {
      font-family: 'Poppins', sans-serif;
      margin: 0;
      padding: 0;
      background-color: var(--background-color);
      color: var(--primary-color);
    }

    nav {
      background-color: #fff;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1);
      padding: 15px 30px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    nav .logo img {
      height: 60px;
    }

    nav .nav-links a {
      margin-left: 20px;
      text-decoration: none;
      color: var(--primary-color);
      font-weight: 500;
      transition: color 0.3s;
    }

    nav .nav-links a:hover {
      color: var(--accent-color);
    }

    .container {
      max-width: 1200px;
      margin: 50px auto;
      padding: 20px;
    }

    h2 {
      text-align: center;
      font-size: 2.5rem;
      color: var(--primary-color);
      margin-bottom: 40px;
    }

    .search-bar {
      text-align: center;
      margin-bottom: 40px;
    }

    .search-bar input[type="text"] {
      padding: 10px;
      width: 300px;
      border-radius: 8px;
      border: 1px solid #ccc;
    }

    .search-bar button {
      padding: 10px 20px;
      background-color: var(--primary-color);
      color: white;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      margin-left: 10px;
      font-weight: 500;
    }

    .search-bar button:hover {
      background-color: #3d6a5f;
    }

    .art-grid {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 30px;
      margin-top: 30px;
    }

    .art-box {
      background: var(--card-bg);
      border-left: 5px solid var(--accent-color);
      border-radius: 16px;
      overflow: hidden;
      width: 300px;
      height: 550px;
      box-shadow: 0 8px 16px rgba(0,0,0,0.1);
      transition: transform 0.3s ease;
    }

    .art-box:hover {
      transform: translateY(-8px);
    }

    .art-box img {
      width: 100%;
      height: 350px;
      object-fit: cover;
    }

    .art-box h3 {
      font-size: 1.2rem;
      margin: 12px 0 4px;
      text-align: center;
      color: var(--primary-color);
    }

    .art-box h3 a {
      text-decoration: none;
      color: inherit;
    }

    .art-box p {
      color: #555;
      font-size: 0.95rem;
      text-align: center;
      padding: 0 10px 10px;
    }

    .btn-group {
      text-align: center;
      padding: 10px;
    }

    .btn-group button, .btn-group a {
      margin: 4px 4px;
      padding: 6px 12px;
      border: none;
      border-radius: 6px;
      font-weight: 500;
      cursor: pointer;
      display: inline-block;
    }

    .favorite-btn {
      color: white;
    }

    .favorite-btn.red {
      background-color: red;
    }

    .favorite-btn.gray {
      background-color: gray;
    }

    .btn-group a {
      background: var(--accent-color);
      color: #333;
      text-decoration: none;
    }

    .btn-group a:hover {
      background-color: #dec032;
    }

    .btn {
      display: inline-block;
      margin: 40px auto 0;
      padding: 12px 24px;
      background-color: var(--primary-color);
      color: white;
      border-radius: 6px;
      text-decoration: none;
      font-weight: 600;
      transition: background 0.3s;
    }

    .btn:hover {
      background-color: #3d6a5f;
    }

    footer {
      text-align: center;
      margin-top: 60px;
      padding: 30px;
      background-color: var(--primary-color);
      color: white;
      font-size: 0.95rem;
    }
  </style>
</head>
<body>

  <nav>
    <div class="logo">
      <img src="images/logo.png" alt="Logo">
    </div>
    <div class="nav-links">
      <a href="index.php">Home</a>
      <a href="customization.php">Customization</a>
      <?php if (isset($_SESSION['user_id'])): ?>
        <a href="favourites/favorites.php">My Favorites</a>
        <a href="profile.php">My Profile</a>
        <a href="logout.php" style="color: red;">Logout</a>
      <?php else: ?>
        <a href="login.php">Login / Register</a>
      <?php endif; ?>
    </div>
  </nav>

  <div class="container">
    <h2>Featured Artworks</h2>

    <div class="search-bar">
      <form method="GET">
        <input type="text" name="search" placeholder="Search by title or artist" value="<?= htmlspecialchars($search) ?>">
        <button type="submit">Search</button>
      </form>
    </div>

    <div class="art-grid">
      <?php if (mysqli_num_rows($result) > 0): ?>
        <?php while ($art = mysqli_fetch_assoc($result)): ?>
          <div class="art-box">
            <a href="artwork_detail.php?art_id=<?= $art['id'] ?>">
              <img src="<?= htmlspecialchars($art['image_path']) ?>" alt="<?= htmlspecialchars($art['title']) ?>">
            </a>
            <h3>
              <a href="artwork_detail.php?art_id=<?= $art['id'] ?>">
                <?= htmlspecialchars($art['title']) ?>
              </a>
            </h3>
            <p>₹<?= $art['price'] ?></p>
            <div class="btn-group">
              <?php if (isset($_SESSION['user_id'])): 
                $is_fav = in_array($art['id'], $favorited_ids);
                $fav_class = $is_fav ? 'red' : 'gray';
                $fav_label = $is_fav ? '❤️ Favorited' : '🤍 Favorite';
              ?>
                <button class="favorite-btn <?= $fav_class ?>" onclick="toggleFavorite(<?= $art['id'] ?>, this)">
                  <?= $fav_label ?>
                </button>
              <?php endif; ?>
              <a href="checkout.php?art_id=<?= $art['id'] ?>">Buy Now</a>
            </div>
          </div>
        <?php endwhile; ?>
      <?php else: ?>
        <p style="text-align:center; width:100%;">No artworks found.</p>
      <?php endif; ?>
    </div>

    <div style="text-align: center;">
      <a href="index.php" class="btn">← Back to Home</a>
    </div>
  </div>

  <footer>
    &copy; <?= date("Y") ?> Artistry Market. Crafted with ❤️ for artists and art lovers.
  </footer>

  <script>
    function toggleFavorite(art_id, button) {
        fetch('add_to_favorites.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `art_id=${art_id}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'added') {
                button.classList.remove("gray");
                button.classList.add("red");
                button.innerText = "❤️ Favorited";
            } else if (data.status === 'removed') {
                button.classList.remove("red");
                button.classList.add("gray");
                button.innerText = "🤍 Favorite";
            } else if (data.status === 'not_logged_in') {
                alert("Please log in to favorite artworks.");
            }
        });
    }
  </script>
</body>
</html>
