<?php
session_start();
require_once "db/connect.php";

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user info
$query = "SELECT * FROM users WHERE id = $user_id";
$result = mysqli_query($conn, $query);
$user = mysqli_fetch_assoc($result);

// If user is not artist, redirect to user dashboard
if ($user['user_type'] !== 'artist') {
    header("Location: dashboard/user_dashboard.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>My Profile | Artistry Market</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    :root {
      --primary: #2D4C46;
      --accent: #F6C544;
      --background: #F3E3AC;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Poppins', sans-serif;
    }

    body {
      background-color: var(--background);
      padding: 50px 20px;
      color: var(--primary);
    }

    .container {
      max-width: 700px;
      margin: auto;
      background: #fff;
      border-radius: 16px;
      padding: 40px;
      box-shadow: 0 6px 18px rgba(0, 0, 0, 0.1);
    }

    h2 {
      text-align: center;
      font-size: 2rem;
      color: var(--primary);
      margin-bottom: 30px;
    }

    .profile-info p {
      font-size: 1.05rem;
      margin: 12px 0;
      color: #333;
    }

    .profile-info p strong {
      color: var(--primary);
    }

    .dashboard-links {
      margin-top: 30px;
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 20px;
    }

    .dashboard-links a {
      text-decoration: none;
      background: var(--primary);
      color: white;
      padding: 12px 28px;
      border-radius: 10px;
      font-weight: bold;
      transition: 0.3s;
    }

    .dashboard-links a:hover {
      background: #3c6e61;
    }

    .back-home {
      text-align: center;
      margin-top: 40px;
    }

    .back-home a {
      color: var(--primary);
      text-decoration: none;
      font-weight: bold;
      transition: 0.3s;
    }

    .back-home a:hover {
      text-decoration: underline;
    }

    @media (max-width: 480px) {
      .container {
        padding: 25px;
      }

      .dashboard-links a {
        width: 100%;
        text-align: center;
      }
    }
  </style>
</head>
<body>

  <div class="container">
    <h2>Artist Profile</h2>

    <div class="profile-info">
      <p><strong>Name:</strong> <?= htmlspecialchars($user['username']) ?></p>
      <p><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>
      <p><strong>Phone:</strong> <?= htmlspecialchars($user['phone']) ?></p>
      <p><strong>Role:</strong> <?= ucfirst($user['user_type']) ?></p>
    </div>

    <div class="dashboard-links">
      <a href="dashboard/artist_dashboard.php">Manage Artworks</a>
      <a href="orders/artist_orders.php">View Orders</a>
    </div>

    <div class="back-home">
      <p><a href="index.php">← Back to Home</a></p>
    </div>
  </div>

</body>
</html>
