<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

require_once "db/connect.php";

$art_id = isset($_GET['art_id']) ? intval($_GET['art_id']) : 0;
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_SESSION['user_id'];
    $art_id = $_POST['art_id'];
    $size = $_POST['size'];
    $custom_message = $_POST['custom_message'];

    // Debug: Check if prepare fails
    $stmt = $conn->prepare("INSERT INTO customizations (user_id, art_id, size, custom_message) VALUES (?, ?, ?, ?)");

    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    // Assuming 'size' is a VARCHAR/TEXT column (not INT)
    $stmt->bind_param("iiss", $user_id, $art_id, $size, $custom_message);

    if ($stmt->execute()) {
        $success = "Customization request submitted successfully!";
    } else {
        $success = "Error submitting request: " . $stmt->error;
    }

    $stmt->close();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Customization Request</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background-color: #f3e3ac;
      padding: 40px;
      color: #2D4C46;
    }
    .form-box {
      background: white;
      padding: 30px;
      border-radius: 12px;
      max-width: 600px;
      margin: auto;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
    h2 {
      margin-bottom: 20px;
      text-align: center;
    }
    input, textarea, select {
      width: 100%;
      padding: 10px;
      margin: 10px 0;
      border-radius: 8px;
      border: 1px solid #ccc;
    }
    button {
      background-color: #2D4C46;
      color: white;
      padding: 12px 20px;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      font-weight: bold;
    }
    .success {
      color: green;
      text-align: center;
    }
  </style>
</head>
<body>
  <div class="form-box">
    <h2>Request a Customization</h2>
    <?php if ($success): ?>
      <p class="success"><?= htmlspecialchars($success) ?></p>
    <?php endif; ?>
    <form method="POST">
      <input type="hidden" name="art_id" value="<?= $art_id ?>">
      <label for="size">Preferred Size:</label>
      <select name="size" required>
        <option value="">Select Size</option>
        <option value="A4">A4</option>
        <option value="A3">A3</option>
        <option value="A2">A2</option>
        <option value="Custom">Custom Size</option>
      </select>

      <label for="custom_message">Customization Details:</label>
      <textarea name="custom_message" rows="5" placeholder="Enter any specific requests or details..." required></textarea>

      <button type="submit">Submit Request</button>
    </form>
  </div>
</body>
</html>
