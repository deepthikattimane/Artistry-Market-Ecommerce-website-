<?php
session_start();
require_once "db/connect.php";
$msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $password = $_POST["password"];

    $query = "SELECT * FROM users WHERE email='$email'";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) == 1) {
        $user = mysqli_fetch_assoc($result);
        if (password_verify($password, $user["password"])) {
            $_SESSION["user_id"] = $user["id"];
            $_SESSION["username"] = $user["username"];
            $_SESSION["user_type"] = $user["user_type"];

            if ($user["user_type"] == "artist") {
                header("Location: dashboard/artist_dashboard.php");
            } else {
                header("Location: dashboard/user_dashboard.php");
            }
            exit();
        } else {
            $msg = "Incorrect password.";
        }
    } else {
        $msg = "Email not found.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Login | Artistry Market</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    :root {
      --primary-color: #2D4C46;
      --accent-color: #F6C544;
      --background-color: #F3E3AC;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Poppins', sans-serif;
    }

    body {
      background-color: var(--background-color);
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    .form-container {
      background-color: #fff;
      padding: 40px 30px;
      border-radius: 16px;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
      width: 100%;
      max-width: 420px;
      text-align: center;
    }

    .form-container h2 {
      margin-bottom: 20px;
      color: var(--primary-color);
      font-size: 28px;
    }

    .form-container input {
      width: 100%;
      padding: 12px 15px;
      margin: 10px 0;
      border: 1px solid #ccc;
      border-radius: 10px;
      outline: none;
      transition: 0.3s;
    }

    .form-container input:focus {
      border-color: var(--primary-color);
      box-shadow: 0 0 5px rgba(45, 76, 70, 0.3);
    }

    .form-container button {
      width: 100%;
      padding: 12px;
      background-color: var(--primary-color);
      border: none;
      border-radius: 10px;
      color: white;
      font-weight: bold;
      font-size: 16px;
      margin-top: 10px;
      cursor: pointer;
      transition: background 0.3s;
    }

    .form-container button:hover {
      background-color: #3d6a5f;
    }

    .form-container .msg {
      color: red;
      margin-top: 10px;
      font-size: 14px;
    }

    .form-container p {
      margin-top: 15px;
      font-size: 14px;
    }

    .form-container a {
      color: var(--primary-color);
      text-decoration: none;
      font-weight: bold;
    }

    .form-container a:hover {
      text-decoration: underline;
      color: var(--accent-color);
    }

    @media (max-width: 480px) {
      .form-container {
        padding: 30px 20px;
      }
    }
  </style>
</head>
<body>
  <div class="form-container">
    <h2>Login</h2>
    <form method="post">
      <input type="email" name="email" placeholder="Email" required>
      <input type="password" name="password" placeholder="Password" required>
      <button type="submit">Login</button>
      <p class="msg"><?= $msg ?></p>
      <p>New here? <a href="register.php">Create an account</a></p>
    </form>
  </div>
</body>
</html>
