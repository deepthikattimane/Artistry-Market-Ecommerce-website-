<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Welcome | Artistry Market</title>
  <style>
    :root {
      --primary-color: #2D4C46;
      --accent-color: #F6C544;
      --background-color: #F3E3AC;
      --card-bg: #fff;
      --teal-shade: #5C8C85;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    body {
      background-color: var(--background-color);
      color: var(--primary-color);
      min-height: 100vh;
      animation: fadeIn 1.2s ease-in;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(30px); }
      to { opacity: 1; transform: translateY(0); }
    }

    @keyframes slideIn {
      from { opacity: 0; transform: translateY(40px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .header {
      text-align: center;
      padding: 60px 20px 40px;
    }

    .logo-container {
      display: flex;
      justify-content: center;
      align-items: center;
      gap: 15px;
      margin-bottom: 10px;
    }

    .logo-container img {
      width: 75px;
      height: 75px;
      border-radius: 50%;
      box-shadow: 0 4px 12px rgba(0,0,0,0.2);
      animation: fadeIn 1.5s ease;
    }

    .header h1 {
      font-size: 3rem;
      color: var(--primary-color);
      margin-top: 10px;
      animation: fadeIn 1.3s ease;
    }

    .header p {
      font-size: 1.2rem;
      max-width: 700px;
      margin: auto;
      color: #333;
      animation: fadeIn 1.5s ease;
    }

    .cta-buttons {
      text-align: center;
      margin-top: 40px;
      animation: fadeIn 1.6s ease;
    }

    .cta-buttons a {
      display: inline-block;
      margin: 10px;
      padding: 12px 28px;
      background-color: var(--primary-color);
      color: white;
      text-decoration: none;
      border-radius: 25px;
      font-size: 1rem;
      transition: all 0.3s ease;
      box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }

    .cta-buttons a:hover {
      background-color: var(--teal-shade);
      transform: scale(1.05);
    }

    .features-preview {
      background: var(--card-bg);
      padding: 60px 20px;
      text-align: center;
      border-radius: 30px 30px 0 0;
      margin-top: 60px;
      animation: fadeIn 1.8s ease;
    }

    .features-preview h2 {
      font-size: 2.4rem;
      color: var(--primary-color);
      margin-bottom: 30px;
    }

    .feature-grid {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 30px;
      margin-top: 20px;
    }

    .feature-card {
      background: #fafafa;
      border-left: 5px solid var(--accent-color);
      border-radius: 16px;
      width: 260px;
      padding: 25px 20px;
      text-align: left;
      box-shadow: 0 6px 14px rgba(0, 0, 0, 0.1);
      animation: slideIn 1s ease;
      transition: transform 0.3s ease;
    }

    .feature-card:hover {
      transform: translateY(-5px) scale(1.02);
    }

    .feature-card h3 {
      color: var(--primary-color);
      font-size: 1.2rem;
      margin-bottom: 10px;
    }

    .feature-card p {
      font-size: 0.95rem;
      color: #444;
    }

    .art-images {
      text-align: center;
      margin-top: 50px;
    }

    .art-images img {
      width: 280px;
      height: 320px;
      object-fit: cover;
      margin: 12px;
      border-radius: 14px;
      box-shadow: 0 6px 10px rgba(0,0,0,0.15);
      transition: transform 0.3s ease;
    }

    .art-images img:hover {
      transform: scale(1.08);
    }

    .featured-artists {
      text-align: center;
      padding: 60px 20px;
      background-color: #fff8e7;
    }

    .featured-artists h2 {
      font-size: 2.2rem;
      color: var(--primary-color);
      margin-bottom: 40px;
      animation: fadeIn 2s ease;
    }

    .artist-grid {
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      gap: 30px;
    }

    .artist-card {
      background: #ffffff;
      border-radius: 16px;
      padding: 20px;
      width: 220px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.1);
      transition: transform 0.3s ease;
      animation: slideIn 1.1s ease;
    }

    .artist-card:hover {
      transform: translateY(-8px);
    }

    .artist-card img {
      width: 100%;
      height: 200px;
      object-fit: cover;
      border-radius: 12px;
      margin-bottom: 15px;
    }

    .artist-card h4 {
      font-size: 1.1rem;
      color: var(--primary-color);
      margin-bottom: 6px;
    }

    .artist-card p {
      font-size: 0.9rem;
      color: #444;
    }

    .footer {
      background: var(--primary-color);
      color: #fff;
      text-align: center;
      padding: 30px 20px;
      font-size: 0.95rem;
      margin-top: 60px;
      animation: fadeIn 2.2s ease;
    }
  </style>
</head>
<body>

  <div class="header">
    <div class="logo-container">
      <img src="images/logo.png" alt="Logo">
    </div>
    <h1>Artistry Market</h1>
    <p>Discover, create, and commission stunning digital art — connecting artists with art lovers worldwide.</p>
  </div>

  <div class="cta-buttons">
    <a href="login.php">Login / Register</a>
    <a href="features.php">Explore Features</a>
  </div>

  <div class="features-preview">
    <h2>Why Join Artistry Market?</h2>
    <div class="feature-grid">
      <div class="feature-card">
        <h3>Showcase Your Work</h3>
        <p>Upload high-quality artworks and share them with a global audience.</p>
      </div>
      <div class="feature-card">
        <h3>Commission Requests</h3>
        <p>Artists can take custom art requests and grow their client base.</p>
      </div>
      <div class="feature-card">
        <h3>Print & Purchase</h3>
        <p>Buy or sell digital prints securely through our platform.</p>
      </div>
    </div>

    <div class="art-images">
      <img src="images/naga.jpg" alt="Art Sample 1">
      <img src="images/deep1.jpg" alt="Art Sample 2">
      <img src="images/h1.jpg" alt="Art Sample 3">
    </div>
  </div>

  <!-- Featured Artists Section -->
  <div class="featured-artists">
    <h2>Featured Artists</h2>
    <div class="artist-grid">
      <div class="artist-card">
        <img src="images/naga1.jpg" alt="Artist 1">
        <h4>Nagaveni</h4>
        <p>Concept Artist | Specializes in fantasy and mythological art</p>
      </div>
      <div class="artist-card">
        <img src="images/deepthi1.jpg" alt="Artist 2">
        <h4>Deepthi</h4>
        <p>Character Designer | Focused on unique character concepts</p>
      </div>
      <div class="artist-card">
        <img src="images/hams.jpg" alt="Artist 3">
        <h4>Hamsaveni</h4>
        <p>Expert in anime and game avatars</p>
      </div>
    </div>
  </div>

  <div class="footer">
    &copy; <?= date("Y") ?> Artistry Market. All rights reserved.
  </div>

</body>
</html>
