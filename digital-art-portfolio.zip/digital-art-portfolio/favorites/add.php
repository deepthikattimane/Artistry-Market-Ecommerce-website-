<?php
session_start();
require_once "../db/connect.php";

// Only allow logged-in visitors
if (!isset($_SESSION["user_id"]) || $_SESSION["user_type"] !== "visitor") {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION["user_id"];
$artwork_id = $_POST["artwork_id"];

// Check if already favorited
$check = mysqli_query($conn, "SELECT * FROM favorites WHERE user_id=$user_id AND artwork_id=$artwork_id");
if (mysqli_num_rows($check) == 0) {
    // Add to favorites
    $query = "INSERT INTO favorites (user_id, artwork_id) VALUES ($user_id, $artwork_id)";
    mysqli_query($conn, $query);
}

// Redirect back to artwork or homepage
$redirect = isset($_SERVER["HTTP_REFERER"]) ? $_SERVER["HTTP_REFERER"] : "../index.php";
header("Location: $redirect");
exit();
?>
