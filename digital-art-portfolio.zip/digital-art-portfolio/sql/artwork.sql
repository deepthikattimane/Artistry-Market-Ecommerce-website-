-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 27, 2025 at 11:38 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `digital_art_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `artworks`
--

CREATE TABLE `artworks` (
  `id` int(11) NOT NULL,
  `artist_id` int(11) NOT NULL,
  `title` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `image_path` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `artworks`
--

INSERT INTO `artworks` (`id`, `artist_id`, `title`, `description`, `price`, `image_path`, `created_at`) VALUES
(3, 1, 'Charm', 'bvhjgliug', 400.00, 'images/1752242674_img11 pai.jpg', '2025-07-11 14:04:34'),
(5, 1, 'Peekaboo', 'gdjhgfjlh', 1000.00, 'uploads/img4 pro.jpg', '2025-07-11 14:32:12'),
(6, 1, 'Templetime', 'mbasnmcvnqbVMB', 1500.00, 'uploads/img 15.jpg', '2025-07-27 08:32:14'),
(7, 1, 'Market Whispers', 'nsvdfwjHLKD', 700.00, 'uploads/img1 pro.jpg', '2025-07-27 08:50:35'),
(8, 1, 'Synchrony', 'sjthwkjharcvbnmvcfdhg', 900.00, 'uploads/im2 pro.jpg', '2025-07-27 08:51:11'),
(9, 1, 'Devaa', 'msbdmnbskjb', 1000.00, 'uploads/img 14.jpg', '2025-07-27 08:51:56'),
(10, 1, 'beautiee', 'nnvahgjkdfaj', 800.00, 'uploads/img 13.jpg', '2025-07-27 08:52:32'),
(11, 1, 'Night speaks', 'msndbmbsjkgbkajbkj', 1000.00, 'uploads/img 15.jpg', '2025-07-27 08:53:03'),
(12, 1, 'Heritage', 'msvdfhnvakjf,j', 1500.00, 'uploads/img 12 pai.jpg', '2025-07-27 08:53:43'),
(13, 1, 'calm', 'snbdvamnvf', 800.00, 'uploads/img5 pro.jpg', '2025-07-27 08:54:26');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `artworks`
--
ALTER TABLE `artworks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `artist_id` (`artist_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `artworks`
--
ALTER TABLE `artworks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `artworks`
--
ALTER TABLE `artworks`
  ADD CONSTRAINT `artworks_ibfk_1` FOREIGN KEY (`artist_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
