<?php
session_start();
require_once "db/connect.php";

$art_id = isset($_GET['art_id']) ? intval($_GET['art_id']) : 0;

$sql = "SELECT a.*, u.username AS artist_name 
        FROM artworks a 
        JOIN users u ON a.artist_id = u.id 
        WHERE a.id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $art_id);
$stmt->execute();
$result = $stmt->get_result();
$art = $result->fetch_assoc();

if (!$art) {
    echo "<h2>Artwork not found.</h2>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title><?= htmlspecialchars($art['title']) ?> | Artistry Market</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background-color: #f9f5e9;
      margin: 0;
      padding: 0;
      color: #2D4C46;
    }
    .container {
      max-width: 1000px;
      margin: 50px auto;
      padding: 20px;
      background: white;
      border-radius: 12px;
      box-shadow: 0 8px 16px rgba(0,0,0,0.1);
    }
    .art-image {
      max-width: 100%;
      height: auto;
      border-radius: 12px;
    }
    h1 {
      font-size: 2rem;
      margin: 20px 0 10px;
    }
    .details {
      margin-top: 20px;
    }
    .details p {
      font-size: 1rem;
      line-height: 1.5;
      margin: 10px 0;
    }
    .price {
      font-size: 1.5rem;
      color: #F6C544;
      font-weight: bold;
    }
    .btn {
      display: inline-block;
      padding: 10px 20px;
      margin-top: 20px;
      background-color: #2D4C46;
      color: white;
      text-decoration: none;
      border-radius: 6px;
      font-weight: 600;
    }
    .btn:hover {
      background-color: #3d6a5f;
    }
  </style>
</head>
<body>

<div class="container">
  <img class="art-image" src="<?= htmlspecialchars($art['image_path']) ?>" alt="<?= htmlspecialchars($art['title']) ?>">
  <h1><?= htmlspecialchars($art['title']) ?></h1>
  <p><strong>By:</strong> <?= htmlspecialchars($art['artist_name']) ?></p>
  <p class="price">₹<?= $art['price'] ?></p>
  <div class="details">
    <p><strong>Description:</strong> <?= nl2br(htmlspecialchars($art['description'])) ?></p>
    <p><strong>Category:</strong> <?= htmlspecialchars($art['category']) ?></p>
    <p><strong>Uploaded on:</strong> <?= date('F j, Y', strtotime($art['created_at'])) ?></p>
  </div>

  <a href="checkout.php?art_id=<?= $art['id'] ?>" class="btn">Buy Now</a>
  <a href="features.php" class="btn" style="background:#ccc; color:#333;">← Back to Features</a>
</div>

</body>
</html>
