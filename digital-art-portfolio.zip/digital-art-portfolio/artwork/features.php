<?php
session_start();
require_once "db/connect.php";

// Fetch 6 featured artworks (you can modify limit)
$sql = "SELECT a.*, u.username AS artist_name 
        FROM artworks a 
        JOIN users u ON a.artist_id = u.id 
        ORDER BY RAND() LIMIT 6";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Featured Artworks | Artistry Market</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background-color: #f9f5e9;
      margin: 0;
      padding: 0;
    }
    .container {
      max-width: 1100px;
      margin: 60px auto;
      padding: 0 20px;
    }
    h2 {
      text-align: center;
      font-size: 2rem;
      margin-bottom: 30px;
      color: #2D4C46;
    }
    .features-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 30px;
    }
    .art-box {
      background: #fff;
      padding: 15px;
      border-radius: 12px;
      box-shadow: 0 8px 16px rgba(0,0,0,0.1);
      transition: transform 0.3s, box-shadow 0.3s;
      text-align: center;
    }
    .art-box:hover {
      transform: translateY(-8px);
      box-shadow: 0 12px 20px rgba(0,0,0,0.2);
    }
    .art-box img {
      max-width: 100%;
      height: 200px;
      object-fit: cover;
      border-radius: 10px;
    }
    .art-box h3 {
      font-size: 1.2rem;
      margin: 12px 0 5px;
      color: #2D4C46;
    }
    .art-box p {
      font-size: 0.95rem;
      color: #555;
      margin-bottom: 10px;
    }
    .price {
      font-weight: bold;
      color: #F6C544;
    }
    .btn {
      display: inline-block;
      margin-top: 10px;
      padding: 8px 16px;
      background-color: #2D4C46;
      color: #fff;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      text-decoration: none;
      transition: background 0.3s;
    }
    .btn:hover {
      background-color: #3d6a5f;
    }
  </style>
</head>
<body>

<div class="container">
  <h2>Featured Artworks</h2>
  <div class="features-grid">
    <?php while($art = $result->fetch_assoc()): ?>
      <div class="art-box">
        <a href="artwork_detail.php?art_id=<?= $art['id'] ?>">
          <img src="<?= htmlspecialchars($art['image_path']) ?>" alt="<?= htmlspecialchars($art['title']) ?>">
        </a>
        <h3>
          <a href="artwork_detail.php?art_id=<?= $art['id'] ?>" style="text-decoration: none; color: inherit;">
            <?= htmlspecialchars($art['title']) ?>
          </a>
        </h3>
        <p>By: <?= htmlspecialchars($art['artist_name']) ?></p>
        <p class="price">₹<?= $art['price'] ?></p>
        <a href="checkout.php?art_id=<?= $art['id'] ?>" class="btn">Buy Now</a>
      </div>
    <?php endwhile; ?>
  </div>
</div>

</body>
</html>
