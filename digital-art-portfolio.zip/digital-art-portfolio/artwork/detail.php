<?php
session_start();
require_once "../db/connect.php";

if (!isset($_GET["id"])) {
    echo "Artwork not found.";
    exit();
}

$artwork_id = $_GET["id"];

// Fetch artwork & artist info
$query = "SELECT a.*, a.artist_id, u.username AS artist_name 
          FROM artworks a
          JOIN users u ON a.artist_id = u.id
          WHERE a.id = $artwork_id";
$result = mysqli_query($conn, $query);
$art = mysqli_fetch_assoc($result);

if (!$art) {
    echo "Artwork not found.";
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title><?= $art["title"] ?> | Digital Art Portfolio</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="container">
        <a href="../index.php" class="btn">← Back to Gallery</a>

        <div class="art-detail">
            <img src="../<?= $art["image_path"] ?>" alt="<?= $art["title"] ?>">
            <div class="art-info">
                <h2><?= $art["title"] ?></h2>
                <p><strong>By:</strong> <?= $art["artist_name"] ?></p>
                <p><strong>Description:</strong><br><?= $art["description"] ?></p>
                <p><strong>Price:</strong> $<?= $art["price"] ?></p>

                <?php if (isset($_SESSION["user_type"]) && $_SESSION["user_type"] === "visitor"): ?>
                    <form action="../favorites/add.php" method="POST">
                        <input type="hidden" name="artwork_id" value="<?= $art["id"] ?>">
                        <button class="fav-btn">❤️ Add to Favorites</button>
                    </form>

                    <form action="../orders/buy.php" method="POST">
                        <input type="hidden" name="artwork_id" value="<?= $art["id"] ?>">
                        <input type="hidden" name="price" value="<?= $art["price"] ?>">
                        <label>Quantity:</label>
                        <input type="number" name="quantity" value="1" min="1" required>
                        <button class="btn">🛒 Buy Print</button>
                        <a href="../commissions/request.php?artist_id=<?= $art['artist_id'] ?>" class="btn" style="margin-top:10px;"> Request Commission</a>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>
