<?php
session_start();
require_once "../db/connect.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $artist_id = $_SESSION["user_id"];
    $title = $_POST["title"];
    $description = $_POST["description"];
    $price = $_POST["price"];

    // Image handling
    $target_dir = "../uploads/";
    $file_name = basename($_FILES["image"]["name"]);
    $target_file = $target_dir . $file_name;

    if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
        // Store relative path
        $image_path = "uploads/" . $file_name;

        // Save to DB
        $stmt = $conn->prepare("INSERT INTO artworks (artist_id, title, description, price, image_path) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("issds", $artist_id, $title, $description, $price, $image_path);

        if ($stmt->execute()) {
            echo "success"; // ✅ Return 'success' for AJAX to catch
            exit();
        } else {
            echo "Failed to save to database.";
            exit();
        }
    } else {
        echo "Image upload failed.";
        exit();
    }
}
?>
