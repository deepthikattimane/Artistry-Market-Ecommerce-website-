<?php
session_start();
if (!isset($_SESSION["user_id"]) || $_SESSION["user_type"] != "visitor") {
    header("Location: ../login.php");
    exit();
}

require_once "../db/connect.php";
$user_id = $_SESSION["user_id"];

// Fetch favorites
$fav_query = "SELECT f.*, a.title, a.price, a.image_path, u.username AS artist_name, f.artwork_id
              FROM favorites f
              JOIN artworks a ON f.artwork_id = a.id
              JOIN users u ON a.artist_id = u.id
              WHERE f.user_id = $user_id";
$fav_result = mysqli_query($conn, $fav_query);

// Fetch orders
$order_query = "SELECT o.*, a.title, a.image_path, u.username AS artist_name
                FROM orders o
                JOIN artworks a ON o.artwork_id = a.id
                JOIN users u ON a.artist_id = u.id
                WHERE o.user_id = $user_id
                ORDER BY o.order_date DESC";
$order_result = mysqli_query($conn, $order_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Your Dashboard | Artistry Market</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #2D4C46;
            --accent: #F6C544;
            --bg: #F3E3AC;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background-color: var(--bg);
            padding: 40px 20px;
            color: var(--primary);
        }

        .dashboard {
            max-width: 1200px;
            margin: auto;
            background: #fff;
            padding: 40px;
            border-radius: 16px;
            box-shadow: 0 6px 16px rgba(0,0,0,0.1);
            animation: fadeIn 1.2s ease-in;
        }

        h2 {
            text-align: center;
            font-size: 2rem;
            margin-bottom: 30px;
        }

        .btn-logout {
            float: right;
            padding: 8px 20px;
            background: var(--primary);
            color: white;
            border-radius: 8px;
            text-decoration: none;
            font-weight: bold;
            transition: background 0.3s ease;
        }

        .btn-logout:hover {
            background: #1c362f;
        }

        h3 {
            margin-top: 50px;
            margin-bottom: 20px;
            font-size: 1.5rem;
            color: var(--primary);
        }

        .gallery {
            display: flex;
            flex-wrap: wrap;
            gap: 30px;
            justify-content: left;
        }

        .art-box {
            background: #fff;
            border-radius: 14px;
            box-shadow: 0 5px 14px rgba(0,0,0,0.08);
            width: 260px;
            overflow: hidden;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            animation: fadeInUp 0.8s ease;
        }

        .art-box:hover {
            transform: translateY(-8px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.12);
        }

        .art-box img {
            width: 100%;
            height: 300px;
            object-fit: cover;
        }

        .art-box h4 {
            font-size: 1.1rem;
            margin: 10px;
            text-align: center;
        }

        .art-box p {
            font-size: 0.95rem;
            color: #444;
            margin: 6px 10px;
            text-align: center;
        }

        .art-box small {
            color: #777;
            font-size: 0.85rem;
            display: block;
            text-align: center;
        }

        .buy-now-button {
            padding: 8px 16px;
            background-color: var(--accent);
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
            margin: 10px auto;
            display: block;
            color: #000;
        }

        .buy-now-button:hover {
            background-color: #e6b700;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(40px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @media (max-width: 600px) {
            .dashboard {
                padding: 25px 15px;
            }

            .gallery {
                gap: 20px;
            }

            .art-box {
                width: 100%;
            }

            .btn-logout {
                float: none;
                display: block;
                margin: 20px auto 0;
                text-align: center;
            }
        }
    </style>
</head>
<body>

<div class="dashboard">
    <a href="../index.php" class="btn-logout">Logout</a>
    <h2>Welcome, <?= htmlspecialchars($_SESSION["username"]) ?></h2>

    <h3>❤️ Your Favorite Artworks</h3>
    <div class="gallery">
        <?php if (mysqli_num_rows($fav_result) > 0): ?>
            <?php while ($row = mysqli_fetch_assoc($fav_result)) { ?>
                <div class="art-box">
                    <img src="../<?= htmlspecialchars($row["image_path"]) ?>" alt="<?= htmlspecialchars($row["title"]) ?>">
                    <h4><?= htmlspecialchars($row["title"]) ?></h4>
                    <p>By <?= htmlspecialchars($row["artist_name"]) ?></p>
                    <p>₹<?= htmlspecialchars($row["price"]) ?></p>
                    <form action="../checkout.php" method="GET" style="text-align: center;">
                        <input type="hidden" name="art_id" value="<?= $row['artwork_id'] ?>">
                        <button type="submit" class="buy-now-button">Buy Now</button>
                    </form>
                </div>
            <?php } ?>
        <?php else: ?>
            <p style="text-align:center;">No favorites yet.</p>
        <?php endif; ?>
    </div>

    <h3>🛒 Your Orders</h3>
    <div class="gallery">
        <?php if (mysqli_num_rows($order_result) > 0): ?>
            <?php while ($row = mysqli_fetch_assoc($order_result)) { ?>
                <div class="art-box">
                    <img src="../<?= htmlspecialchars($row["image_path"]) ?>" alt="<?= htmlspecialchars($row["title"]) ?>">
                    <h4><?= htmlspecialchars($row["title"]) ?></h4>
                    <p>By <?= htmlspecialchars($row["artist_name"]) ?></p>
                    <p>Qty: <?= $row["quantity"] ?> | Total: ₹<?= $row["total_price"] ?></p>
                    <p><small>Ordered on <?= date("M d, Y", strtotime($row["order_date"])) ?></small></p>
                </div>
            <?php } ?>
        <?php else: ?>
            <p style="text-align:center;">No orders placed yet.</p>
        <?php endif; ?>
    </div>
</div>

</body>
</html>
