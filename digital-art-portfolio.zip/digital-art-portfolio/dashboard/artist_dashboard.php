<?php
session_start();
if (!isset($_SESSION["user_id"]) || $_SESSION["user_type"] != "artist") {
    header("Location: ../login.php");
    exit();
}

require_once "../db/connect.php";
$artist_id = $_SESSION["user_id"];

// Commission status filter
$status_filter = isset($_GET['status']) ? $_GET['status'] : 'all';

// Fetch artworks
$art_stmt = $conn->prepare("SELECT * FROM artworks WHERE artist_id = ? ORDER BY created_at DESC");
$art_stmt->bind_param("i", $artist_id);
$art_stmt->execute();
$art_result = $art_stmt->get_result();

// Fetch commissions with status filter
$comm_sql = "SELECT c.*, u.username AS from_user
             FROM commissions c
             JOIN users u ON c.user_id = u.id
             WHERE c.artist_id = ?";
if ($status_filter !== 'all') {
    $comm_sql .= " AND c.status = ?";
    $comm_stmt = $conn->prepare($comm_sql);
    $comm_stmt->bind_param("is", $artist_id, $status_filter);
} else {
    $comm_stmt = $conn->prepare($comm_sql);
    $comm_stmt->bind_param("i", $artist_id);
}
$comm_stmt->execute();
$commissions = $comm_stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Artist Dashboard | Artistry Market</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    :root {
      --primary: #2D4C46;
      --accent: #F6C544;
      --background: #F3E3AC;
    }
    body {
      font-family: 'Poppins', sans-serif;
      background-color: var(--background);
      padding: 30px;
      color: var(--primary);
    }
    .dashboard {
      max-width: 1200px;
      margin: auto;
      background: #fff;
      padding: 40px;
      border-radius: 16px;
      box-shadow: 0 6px 18px rgba(0, 0, 0, 0.1);
    }
    .dashboard h2 {
      font-size: 2rem;
    }
    .btn-logout {
      float: right;
      background-color: red;
      color: white;
      padding: 8px 16px;
      border-radius: 8px;
      text-decoration: none;
      font-weight: bold;
    }
    form input, form textarea, form select, form button {
      width: 100%;
      padding: 10px;
      margin: 8px 0;
      border-radius: 8px;
      border: 1px solid #ccc;
    }
    form button {
      background-color: var(--primary);
      color: white;
      border: none;
      font-weight: bold;
      cursor: pointer;
    }
    .gallery {
      display: flex;
      flex-wrap: wrap;
      gap: 20px;
      margin-top: 20px;
    }
    .art-box {
      width: 200px;
      background: #fafafa;
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
      text-align: center;
    }
    .art-box img {
      width: 100%;
      height: 300px;
      object-fit: cover;
    }
    table {
      width: 100%;
      margin-top: 20px;
      border-collapse: collapse;
    }
    table th, td {
      padding: 12px;
      border: 1px solid #ccc;
      text-align: center;
    }
    table th {
      background: var(--primary);
      color: white;
    }
    .btn {
      padding: 6px 12px;
      border-radius: 6px;
      background-color: var(--primary);
      color: white;
      border: none;
    }
    .btn-red {
      background-color: red;
    }
    .btn-red:hover {
      background-color: darkred;
    }
    .filter-form {
      text-align: right;
      margin-top: 10px;
    }
  </style>
</head>
<body>
<div class="dashboard">
  <h2>Welcome, <?= htmlspecialchars($_SESSION["username"]) ?></h2>
  <a href="../logout.php" class="btn-logout">Logout</a>

<h3>Upload New Artwork</h3>
<form id="uploadForm" enctype="multipart/form-data">
  <input type="text" name="title" placeholder="Artwork Title" required>
  <textarea name="description" placeholder="Description" required></textarea>
  <input type="number" name="price" step="0.01" placeholder="Price (₹)" required>
  <input type="file" name="image" accept="image/*" required>
  <button type="submit">Upload</button>
</form>

<div id="uploadMessage" style="margin-top: 10px; color: green;"></div>


  <h3>Your Uploaded Artworks</h3>
  <div class="gallery">
    <?php while ($row = mysqli_fetch_assoc($art_result)) { ?>
      <div class="art-box">
        <img src="../<?= htmlspecialchars($row['image_path']) ?>" alt="<?= htmlspecialchars($row['title']) ?>">
        <h4><?= htmlspecialchars($row['title']) ?></h4>
        <p>₹<?= number_format($row['price'], 2) ?></p>
      </div>
    <?php } ?>
  </div>

  <h3>Customization Requests</h3>
  <div class="filter-form">
    <form method="GET">
      <label for="status">Filter:</label>
      <select name="status" id="status" onchange="this.form.submit()">
        <option value="all" <?= $status_filter == 'all' ? 'selected' : '' ?>>All</option>
        <option value="pending" <?= $status_filter == 'pending' ? 'selected' : '' ?>>Pending</option>
        <option value="accepted" <?= $status_filter == 'accepted' ? 'selected' : '' ?>>Accepted</option>
        <option value="declined" <?= $status_filter == 'declined' ? 'selected' : '' ?>>Declined</option>
      </select>
    </form>
  </div>

  <?php if (mysqli_num_rows($commissions) > 0): ?>
    <table>
      <tr>
        <th>From</th>
        <th>Title</th>
        <th>Description</th>
        <th>Size</th>
        <th>Budget</th>
        <th>Deadline</th>
        <th>Status</th>
        <th>Actions</th>
      </tr>
      <?php while ($c = mysqli_fetch_assoc($commissions)) { ?>
        <tr>
          <td><?= htmlspecialchars($c['from_user']) ?></td>
          <td><?= htmlspecialchars($c['title']) ?></td>
          <td><?= nl2br(htmlspecialchars($c['description'])) ?></td>
          <td><?= htmlspecialchars($c['size']) ?></td>
          <td>₹<?= number_format($c['budget'], 2) ?></td>
          <td><?= htmlspecialchars($c['deadline']) ?></td>
          <td><?= ucfirst($c['status']) ?></td>
          <td>
            <?php if ($c['status'] == 'pending'): ?>
              <form action="../commissions/update_status.php" method="POST" style="display:inline;">
                <input type="hidden" name="id" value="<?= $c['id'] ?>">
                <button name="action" value="accepted" class="btn">✔ Accept</button>
              </form>
              <form action="../commissions/update_status.php" method="POST" style="display:inline;">
                <input type="hidden" name="id" value="<?= $c['id'] ?>">
                <button name="action" value="declined" class="btn btn-red">✖ Decline</button>
              </form>
            <?php else: ?>
              <em>—</em>
            <?php endif; ?>
          </td>
        </tr>
      <?php } ?>
    </table>
  <?php else: ?>
    <p>No commission requests found.</p>
  <?php endif; ?>
</div>
<script>
document.getElementById('uploadForm').addEventListener('submit', function (e) {
    e.preventDefault();

    const form = e.target;
    const formData = new FormData(form);
    const messageDiv = document.getElementById('uploadMessage');

    fetch('../artwork/upload.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.text())
    .then(data => {
        if (data.includes("success")) {
            messageDiv.textContent = "🎉 Artwork uploaded successfully!";
            form.reset();
            // Optionally reload the gallery:
            setTimeout(() => location.reload(), 1000);
        } else {
            messageDiv.style.color = "red";
            messageDiv.textContent = data;
        }
    })
    .catch(err => {
        messageDiv.style.color = "red";
        messageDiv.textContent = "An error occurred while uploading.";
    });
});
</script>

</body>
</html>
