<?php
session_start();
require_once "../db/connect.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["user_type"] != "visitor") {
    header("Location: ../login.php");
    exit();
}

if (!isset($_GET["artist_id"])) {
    echo "Artist not found.";
    exit();
}

$artist_id = $_GET["artist_id"];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Request Commission</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="container">
    <h2>Commission Request</h2>
    <form action="submit.php" method="POST">
        <input type="hidden" name="artist_id" value="<?= $artist_id ?>">

        <input type="text" name="title" placeholder="Artwork Title" required>
        <textarea name="description" placeholder="Describe what you want" required></textarea>
        <input type="text" name="size" placeholder="Size (e.g. A4, 1080x1080)" required>
        <input type="number" step="0.01" name="budget" placeholder="Budget in $" required>
        <label>Deadline:</label>
        <input type="date" name="deadline" required>

        <button class="btn" type="submit">Send Request</button>
    </form>
</div>
</body>
</html>
