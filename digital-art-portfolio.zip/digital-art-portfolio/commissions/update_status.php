<?php
session_start();
require_once "../db/connect.php";

// Only artist can access
if (!isset($_SESSION["user_id"]) || $_SESSION["user_type"] != "artist") {
    header("Location: ../login.php");
    exit();
}

$artist_id = $_SESSION["user_id"];
$commission_id = intval($_POST["id"]);
$new_status = $_POST["action"];

if (!in_array($new_status, ['accepted', 'declined'])) {
    die("Invalid status.");
}

// Update only if commission belongs to logged-in artist
$query = "UPDATE commissions 
          SET status = '$new_status' 
          WHERE id = $commission_id AND artist_id = $artist_id";

if (mysqli_query($conn, $query)) {
    header("Location: ../dashboard/artist_dashboard.php");
    exit();
} else {
    echo "Error updating status: " . mysqli_error($conn);
}
?>
