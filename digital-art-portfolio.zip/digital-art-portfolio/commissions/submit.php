<?php
session_start();
require_once "../db/connect.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION["user_id"];
$artist_id = $_POST["artist_id"];
$title = mysqli_real_escape_string($conn, $_POST["title"]);
$description = mysqli_real_escape_string($conn, $_POST["description"]);
$size = $_POST["size"];
$budget = $_POST["budget"];
$deadline = $_POST["deadline"];

$query = "INSERT INTO commissions (artist_id, user_id, title, description, size, budget, deadline)
          VALUES ('$artist_id', '$user_id', '$title', '$description', '$size', '$budget', '$deadline')";

if (mysqli_query($conn, $query)) {
    header("Location: ../dashboard/user_dashboard.php?status=commission_sent");
} else {
    echo "Error: " . mysqli_error($conn);
}
?>
