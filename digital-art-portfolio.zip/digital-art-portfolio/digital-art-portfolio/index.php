<?php
session_start();
require_once "db/connect.php";

$query = "SELECT a.*, u.username AS artist_name 
          FROM artworks a
          JOIN users u ON a.artist_id = u.id
          ORDER BY a.created_at DESC";

$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Digital Art Portfolio</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header class="navbar">
        <h1>🎨 Digital Art Gallery</h1>
        <nav>
            <?php if (isset($_SESSION["user_id"])): ?>
                <a href="dashboard/<?= $_SESSION['user_type'] ?>_dashboard.php">Dashboard</a>
                <a href="logout.php">Logout</a>
            <?php else: ?>
                <a href="login.php">Login</a>
                <a href="register.php">Register</a>
            <?php endif; ?>
        </nav>
    </header>

    <div class="container">
        <h2>Featured Artworks</h2>
        <div class="gallery">
            <?php while ($art = mysqli_fetch_assoc($result)) { ?>
                <div class="art-box">
                    <img src="<?= $art['image_path'] ?>" alt="<?= $art['title'] ?>">
                    <h4><?= $art['title'] ?></h4>
                    <p>By <?= $art['artist_name'] ?></p>
                    <p>$<?= $art['price'] ?></p>

                    <a href="artwork/detail.php?id=<?= $art['id'] ?>" class="btn">View Details</a>

                    <?php if (isset($_SESSION["user_type"]) && $_SESSION["user_type"] == "visitor"): ?>
                        <form action="favorites/add.php" method="POST" style="margin-top: 10px;">
                            <input type="hidden" name="artwork_id" value="<?= $art['id'] ?>">
                            <button class="fav-btn">❤️ Add to Favorites</button>
                        </form>
                    <?php endif; ?>
                </div>
            <?php } ?>
        </div>
    </div>
</body>
</html>
