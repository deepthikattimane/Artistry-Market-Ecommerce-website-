<?php
session_start();
if (!isset($_SESSION["user_id"]) || $_SESSION["user_type"] != "visitor") {
    header("Location: ../login.php");
    exit();
}

require_once "../db/connect.php";
$user_id = $_SESSION["user_id"];

// Fetch favorites
$fav_query = "SELECT f.*, a.title, a.price, a.image_path, u.username AS artist_name
              FROM favorites f
              JOIN artworks a ON f.artwork_id = a.id
              JOIN users u ON a.artist_id = u.id
              WHERE f.user_id = $user_id";
$fav_result = mysqli_query($conn, $fav_query);

// Fetch orders
$order_query = "SELECT o.*, a.title, a.image_path, u.username AS artist_name
                FROM orders o
                JOIN artworks a ON o.artwork_id = a.id
                JOIN users u ON a.artist_id = u.id
                WHERE o.user_id = $user_id
                ORDER BY o.order_date DESC";
$order_result = mysqli_query($conn, $order_query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Your Dashboard</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="dashboard">
        <h2>Welcome, <?= $_SESSION["username"] ?></h2>
        <a href="../logout.php" class="btn-logout">Logout</a>

        <h3>❤️ Your Favorite Artworks</h3>
        <div class="gallery">
            <?php while ($row = mysqli_fetch_assoc($fav_result)) { ?>
                <div class="art-box">
                    <img src="../<?= $row["image_path"] ?>" alt="<?= $row["title"] ?>">
                    <h4><?= $row["title"] ?></h4>
                    <p>By <?= $row["artist_name"] ?></p>
                    <p>$<?= $row["price"] ?></p>
                </div>
            <?php } ?>
        </div>

        <h3>🛒 Your Orders</h3>
        <div class="gallery">
            <?php while ($row = mysqli_fetch_assoc($order_result)) { ?>
                <div class="art-box">
                    <img src="../<?= $row["image_path"] ?>" alt="<?= $row["title"] ?>">
                    <h4><?= $row["title"] ?></h4>
                    <p>By <?= $row["artist_name"] ?></p>
                    <p>Qty: <?= $row["quantity"] ?> | Total: $<?= $row["total_price"] ?></p>
                    <p><small>Ordered on <?= date("M d, Y", strtotime($row["order_date"])) ?></small></p>
                </div>
            <?php } ?>
        </div>
    </div>
</body>
</html>
