<?php
session_start();
if (!isset($_SESSION["user_id"]) || $_SESSION["user_type"] != "artist") {
    header("Location: ../login.php");
    exit();
}

require_once "../db/connect.php";
$artist_id = $_SESSION["user_id"];

// Fetch artworks
$query = "SELECT * FROM artworks WHERE artist_id = $artist_id ORDER BY created_at DESC";
$result = mysqli_query($conn, $query);

// Fetch commissions
$commission_query = "SELECT c.*, u.username AS from_user
                     FROM commissions c
                     JOIN users u ON c.user_id = u.id
                     WHERE c.artist_id = $artist_id
                     ORDER BY c.created_at DESC";
$commissions = mysqli_query($conn, $commission_query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Artist Dashboard</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="dashboard">
        <h2>Welcome, <?= $_SESSION["username"] ?></h2>
        <a href="../logout.php" class="btn-logout">Logout</a>

        <h3>🎨Upload New Artwork</h3>
        <form action="../artwork/upload.php" method="POST" enctype="multipart/form-data">
            <input type="text" name="title" placeholder="Artwork Title" required>
            <textarea name="description" placeholder="Description" required></textarea>
            <input type="number" name="price" step="0.01" placeholder="Price ($)" required>
            <input type="file" name="image" accept="image/*" required>
            <button type="submit">Upload</button>
        </form>

        <h3>Your Uploaded Artworks</h3>
        <div class="gallery">
            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                <div class="art-box">
                    <img src="../<?= $row['image_path'] ?>" alt="<?= $row['title'] ?>">
                    <h4><?= $row['title'] ?></h4>
                    <p>$<?= $row['price'] ?></p>
                </div>
            <?php } ?>
        </div>

        <h3>Commission Requests</h3>
        <?php if (mysqli_num_rows($commissions) > 0): ?>
            <table border="1" cellpadding="8" cellspacing="0" style="width:100%; margin-top: 20px;">
                <tr>
                    <th>From</th>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Size</th>
                    <th>Budget</th>
                    <th>Deadline</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
                <?php while ($c = mysqli_fetch_assoc($commissions)) { ?>
                    <tr>
                        <td><?= htmlspecialchars($c['from_user']) ?></td>
                        <td><?= htmlspecialchars($c['title']) ?></td>
                        <td><?= nl2br(htmlspecialchars($c['description'])) ?></td>
                        <td><?= htmlspecialchars($c['size']) ?></td>
                        <td>$<?= number_format($c['budget'], 2) ?></td>
                        <td><?= $c['deadline'] ?></td>
                        <td><?= ucfirst($c['status']) ?></td>
                        <td>
                            <?php if ($c['status'] == 'pending'): ?>
                                <form action="../commissions/update_status.php" method="POST" style="display:inline;">
                                    <input type="hidden" name="id" value="<?= $c['id'] ?>">
                                    <button name="action" value="accepted" class="btn">✔ Accept</button>
                                </form>
                                <form action="../commissions/update_status.php" method="POST" style="display:inline;">
                                    <input type="hidden" name="id" value="<?= $c['id'] ?>">
                                    <button name="action" value="declined" class="btn" style="background:red;">✖ Decline</button>
                                </form>
                            <?php else: ?>
                                <em>No actions</em>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php } ?>
            </table>
        <?php else: ?>
            <p>No commission requests yet.</p>
        <?php endif; ?>
    </div>
</body>
</html>
