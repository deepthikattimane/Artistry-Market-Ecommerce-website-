<?php
session_start();
require_once "db/connect.php";
$msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $password = $_POST["password"];

    $query = "SELECT * FROM users WHERE email='$email'";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) == 1) {
        $user = mysqli_fetch_assoc($result);
        if (password_verify($password, $user["password"])) {
            $_SESSION["user_id"] = $user["id"];
            $_SESSION["username"] = $user["username"];
            $_SESSION["user_type"] = $user["user_type"];

            // Redirect based on role
            if ($user["user_type"] == "artist") {
                header("Location: dashboard/artist_dashboard.php");
            } else {
                header("Location: dashboard/user_dashboard.php");
            }
            exit();
        } else {
            $msg = "Incorrect password.";
        }
    } else {
        $msg = "Email not found.";
    }
}
?>

<!-- HTML Form -->
<!DOCTYPE html>
<html>
<head>
    <title>Login | Digital Art Portfolio</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="form-container">
        <h2>Login</h2>
        <form method="post">
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Login</button>
            <p class="msg"><?= $msg ?></p>
            <p>New here? <a href="register.php">Create an account</a></p>
        </form>
    </div>
</body>
</html>
