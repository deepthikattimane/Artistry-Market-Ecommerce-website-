<?php
require_once "db/connect.php";
$msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = mysqli_real_escape_string($conn, $_POST["username"]);
    $email = mysqli_real_escape_string($conn, $_POST["email"]);
    $phone = mysqli_real_escape_string($conn, $_POST["phone"]);
    $password = password_hash($_POST["password"], PASSWORD_BCRYPT);
    $user_type = $_POST["user_type"];

    // Check if email already exists
    $check = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");
    if (mysqli_num_rows($check) > 0) {
        $msg = "Email already registered.";
    } else {
        $query = "INSERT INTO users (username, email, phone, password, user_type)
                  VALUES ('$username', '$email', '$phone', '$password', '$user_type')";
        if (mysqli_query($conn, $query)) {
            header("Location: login.php?success=registered");
            exit();
        } else {
            $msg = "Error: " . mysqli_error($conn);
        }
    }
}
?>

<!-- HTML Form -->
<!DOCTYPE html>
<html>
<head>
    <title>Register | Digital Art Portfolio</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="form-container">
        <h2>Create Account</h2>
        <form method="post">
            <input type="text" name="username" placeholder="Full Name" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="tel" name="phone" placeholder="Phone Number">
            <input type="password" name="password" placeholder="Password" required>
            
            <select name="user_type" required>
                <option value="">I am a...</option>
                <option value="artist">Artist</option>
                <option value="visitor">Visitor</option>
            </select>

            <button type="submit">Register</button>
            <p class="msg"><?= $msg ?></p>
            <p>Already have an account? <a href="login.php">Login</a></p>
        </form>
    </div>
</body>
</html>
