<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Order Successful</title>
  <style>
    body {
      font-family: Arial;
      background: #e7ffe7;
      text-align: center;
      padding: 100px;
    }
    .box {
      background: white;
      padding: 30px;
      border-radius: 12px;
      display: inline-block;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }
    .box h2 {
      color: green;
    }
  </style>
</head>
<body>
  <div class="box">
    <h2>✅ Order placed successfully!</h2>
    <p>Thank you for supporting the artist.</p>
    <a href="../features.php">← Back to Features</a>
  </div>
</body>
</html>
