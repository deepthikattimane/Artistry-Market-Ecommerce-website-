<?php
session_start();
require_once "../db/connect.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$art_id = intval($_POST['art_id']);
$quantity = intval($_POST['quantity']);
$address = trim($_POST['address']);
$phone = trim($_POST['phone']);
$pincode = trim($_POST['pincode']);
$payment_method = $_POST['payment_method'] ?? '';

$upi_id = $_POST['upi_id'] ?? null;
$card_name = $_POST['card_name'] ?? null;
$card_number = $_POST['card_number'] ?? null;
$card_expiry = $_POST['card_expiry'] ?? null;
$card_cvv = $_POST['card_cvv'] ?? null;

// Validate input
if (
    $quantity < 1 || empty($address) || empty($phone) || empty($pincode) || empty($payment_method)
) {
    die("Invalid order details.");
}

// Extra validation based on payment method
if ($payment_method === 'UPI' && empty($upi_id)) {
    die("UPI ID is required.");
}
if ($payment_method === 'Card' && (empty($card_name) || empty($card_number) || empty($card_expiry) || empty($card_cvv))) {
    die("All card details are required.");
}

// Prepare SQL
$sql = "INSERT INTO orders (
    user_id, artwork_id, quantity, address, phone, pincode, payment_method, upi_id, card_name, card_number, card_expiry, card_cvv
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("SQL Error: " . $conn->error);
}

$stmt->bind_param(
    "iiisssssssss",
    $user_id,
    $art_id,
    $quantity,
    $address,
    $phone,
    $pincode,
    $payment_method,
    $upi_id,
    $card_name,
    $card_number,
    $card_expiry,
    $card_cvv
);

if ($stmt->execute()) {
    header("Location: success.php");
    exit();
} else {
    echo "Order failed: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
