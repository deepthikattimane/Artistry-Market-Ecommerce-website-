<?php
session_start();
require_once "../db/connect.php";

// Only allow logged-in visitors
if (!isset($_SESSION["user_id"]) || $_SESSION["user_type"] !== "visitor") {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION["user_id"];
$artwork_id = $_POST["artwork_id"];
$quantity = intval($_POST["quantity"]);
$price = floatval($_POST["price"]);

$total = $quantity * $price;

// Save order
$query = "INSERT INTO orders (user_id, artwork_id, quantity, total_price)
          VALUES ($user_id, $artwork_id, $quantity, $total)";
if (mysqli_query($conn, $query)) {
    $msg = "✅ Order placed successfully!";
} else {
    $msg = "❌ Order failed: " . mysqli_error($conn);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Order Status</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="container">
        <a href="../index.php" class="btn">← Back to Gallery</a>
        <h2>Order Confirmation</h2>
        <p><?= $msg ?></p>
    </div>
</body>
</html>
