<?php
session_start();
require_once "../db/connect.php";

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$artist_id = $_SESSION['user_id'];

// Fetch orders for the artist's artworks
$sql = "SELECT o.*, a.title AS artwork_title, u.username AS customer_name, u.email AS customer_email 
        FROM orders o 
        JOIN artworks a ON o.artwork_id = a.id 
        JOIN users u ON o.user_id = u.id 
        WHERE a.artist_id = $artist_id 
        ORDER BY o.id DESC";

$result = mysqli_query($conn, $sql);

// Handle SQL errors
if (!$result) {
    die("Query Error: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Artist Orders | Artistry Market</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background: #f7f7f7;
      padding: 40px;
    }

    .container {
      max-width: 1000px;
      margin: auto;
      background: #fff;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }

    h2 {
      text-align: center;
      margin-bottom: 30px;
      color: rgb(60, 139, 218);
    }

    table {
      width: 100%;
      border-collapse: collapse;
      font-size: 0.95rem;
    }

    th, td {
      border: 1px solid #ddd;
      padding: 12px;
      text-align: center;
    }

    th {
      background-color: rgb(60, 139, 218);
      color: black;
    }

    tr:nth-child(even) {
      background-color: #f9f9f9;
    }

    .status {
      font-weight: bold;
      padding: 6px 10px;
      border-radius: 6px;
      color: black;
    }

    .pending {
      background: rgb(60, 139, 218);
    }

    .completed {
      background: #27ae60;
    }

    .cancelled {
      background: #e74c3c;
    }

    .back {
      text-align: center;
      margin-top: 30px;
    }

    .back a {
      text-decoration: none;
      color: rgb(60, 139, 218);
      font-weight: bold;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>Orders Received</h2>

    <?php
    $total_amount = 0;
    if (mysqli_num_rows($result) > 0): ?>
    <table>
      <tr>
        <th>Artwork</th>
        <th>Customer</th>
        <th>Email</th>
        <th>Quantity</th>
        <th>Total Price (₹)</th>
        <th>Status</th>
      </tr>
      <?php while ($order = mysqli_fetch_assoc($result)): ?>
      <?php
        $status = isset($order['status']) && $order['status'] !== '' ? strtolower($order['status']) : 'pending';
        $total_amount += (float)$order['total_price'];
      ?>
      <tr>
        <td><?= htmlspecialchars($order['artwork_title']) ?></td>
        <td><?= htmlspecialchars($order['customer_name']) ?></td>
        <td><?= htmlspecialchars($order['customer_email']) ?></td>
        <td><?= (int)$order['quantity'] ?></td>
        <td><?= number_format((float)$order['total_price'], 2) ?></td>
        <td>
          <span class="status <?= $status ?>">
            <?= ucfirst($status) ?>
          </span>
        </td>
      </tr>
      <?php endwhile; ?>
      <tr>
        <td colspan="4" style="text-align:right; font-weight:bold;">Total Earnings:</td>
        <td colspan="2" style="font-weight:bold;">₹<?= number_format($total_amount, 2) ?></td>
      </tr>
    </table>
    <?php else: ?>
      <p style="text-align:center;">No orders received yet.</p>
    <?php endif; ?>

    <div class="back">
      <p><a href="../profile.php">← Back to Profile</a></p>
    </div>
  </div>
</body>
</html>
