<?php
session_start();
if (!isset($_SESSION["user_id"]) || $_SESSION["user_type"] != "artist") {
    header("Location: ../login.php");
    exit();
}

require_once "../db/connect.php";

$title = mysqli_real_escape_string($conn, $_POST["title"]);
$description = mysqli_real_escape_string($conn, $_POST["description"]);
$price = $_POST["price"];
$artist_id = $_SESSION["user_id"];

$targetDir = "../images/";
$imageName = basename($_FILES["image"]["name"]);
$targetFile = $targetDir . time() . "_" . $imageName;

if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile)) {
    $imagePath = substr($targetFile, 3); // remove "../"
    $query = "INSERT INTO artworks (artist_id, title, description, price, image_path)
              VALUES ('$artist_id', '$title', '$description', '$price', '$imagePath')";
    mysqli_query($conn, $query);
}

header("Location: ../dashboard/artist_dashboard.php");
exit();
?>
