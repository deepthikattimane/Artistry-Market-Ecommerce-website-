<?php
session_start();
require_once "../db/connect.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user's favorite artworks
$sql = "SELECT a.id AS art_id, a.title, a.description, a.image_path, u.username AS artist_name
        FROM favorites f
        JOIN artworks a ON f.artwork_id = a.id
        JOIN users u ON a.artist_id = u.id
        WHERE f.user_id = ?";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("SQL Error: " . $conn->error);
}
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Favorites</title>
    <link rel="stylesheet" href="../assets/styles.css"> <!-- Optional -->
    <style>
        .favorite-box {
            border: 1px solid #ddd;
            border-radius: 12px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
            padding: 16px;
            margin: 20px;
            width: 300px;
            display: inline-block;
            vertical-align: top;
            background-color: #fff;
            transition: transform 0.2s ease;
        }
        .favorite-box:hover {
            transform: scale(1.02);
        }
        .favorite-box img {
            width: 100%;
            height: 350px;
            object-fit: cover;
            border-radius: 8px;
        }
        .favorite-title {
            font-size: 18px;
            font-weight: bold;
            margin-top: 10px;
        }
        .favorite-artist {
            font-size: 14px;
            color: #777;
        }
        .favorite-description {
            margin-top: 8px;
        }
        .remove-fav {
            background-color: crimson;
            color: #fff;
            border: none;
            padding: 8px 12px;
            border-radius: 8px;
            cursor: pointer;
            margin-top: 12px;
        }
    </style>
</head>
<body>

    <h2 style="text-align:center;">My Favorite Artworks</h2>

    <div style="text-align:center;">
        <?php if ($result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="favorite-box">
                    <img src="../<?php echo htmlspecialchars($row['image_path']); ?>" 
                         alt="Artwork Image"
                         onerror="this.onerror=null;this.src='../assets/no-image.png';">
                    <div class="favorite-title"><?php echo htmlspecialchars($row['title']); ?></div>
                    <div class="favorite-artist">By <?php echo htmlspecialchars($row['artist_name']); ?></div>
                    <div class="favorite-description"><?php echo htmlspecialchars($row['description']); ?></div>
                    <form method="post" action="remove_favorite.php">
                        <input type="hidden" name="art_id" value="<?php echo $row['art_id']; ?>">
                        <button type="submit" class="remove-fav">Remove from Favorites</button>
                    </form>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>You haven't added any favorites yet.</p>
        <?php endif; ?>
    </div>

</body>
</html>
