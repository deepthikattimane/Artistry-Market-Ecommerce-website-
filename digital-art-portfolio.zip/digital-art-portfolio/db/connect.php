<?php
$host = "localhost";
$dbname = "digital_art_db";  // Your database name
$username = "root";          // Default XAMPP username
$password = "";              // Default password is blank

$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
